﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace project_banhang.Models
{
    public class Item
    {
            //thuong tin san pham
            public ItemsList ItemsList { get; set; }
            //so luong
            public int quantity { get; set; }
    }
}
